# Chrome 书签管理器

一个强大的 Chrome 书签管理扩展，提供更好的书签组织和管理体验。

## 功能特点

- 📁 文件夹管理：创建、编辑、删除和移动文件夹
- 🔖 书签管理：添加、编辑、删除和移动书签
- 🔄 拖拽排序：支持书签和文件夹的拖拽排序
- 🔍 快速搜索：实时搜索书签
- 💾 导入/导出：支持书签的导入和导出
- 🌓 深色模式：支持切换深色/浅色主题
- 🔄 实时同步：与 Chrome 书签保持同步
- 🖼️ 网站图标：自动显示网站图标

## 安装方法

1. 克隆或下载本仓库
2. 运行 `npm install` 安装依赖
3. 运行 `npm run build:all` 构建项目
4. 打开 Chrome 浏览器，进入 `chrome://extensions/`
5. 开启右上角的"开发者模式"
6. 点击"加载已解压的扩展程序"
7. 选择项目的 `dist` 目录

## 使用说明

### 基本操作

- 点击扩展图标打开书签管理器
- 左侧显示文件夹列表，右侧显示当前文件夹的书签
- 使用顶部搜索框快速查找书签
- 点击书签卡片上的按钮进行编辑或删除操作
- 点击文件夹上的按钮进行编辑或删除操作

### 拖拽功能

- 拖拽书签到其他位置可以改变顺序
- 拖拽书签到文件夹可以移动书签
- 拖拽文件夹可以改变文件夹顺序
- 拖拽文件夹到其他文件夹可以创建子文件夹

### 导入/导出

- 点击顶部工具栏的导出按钮可以导出所有书签
- 点击导入按钮可以导入之前导出的书签文件

### 设置选项

- 点击设置按钮可以：
  - 切换深色/浅色主题
  - 开启/关闭网站图标显示
  - 设置删除前是否需要确认

## 开发说明

### 项目结构

```
.
├── src/
│   ├── js/
│   │   └── navigation.ts      # 主要的功能实现
│   ├── styles/
│   │   └── navigation.css     # 样式文件
│   ├── types/
│   │   └── chrome.d.ts        # Chrome API 类型定义
│   └── navigation.html        # 主界面 HTML
├── dist/                      # 编译后的文件
├── icons/                     # 扩展图标
├── manifest.json              # 扩展配置文件
├── package.json              # 项目配置文件
└── tsconfig.json             # TypeScript 配置文件
```

### 开发命令

- `npm run build`: 编译 TypeScript 文件
- `npm run watch`: 监听文件变化并自动编译
- `npm run clean`: 清理编译目录
- `npm run copy-assets`: 复制静态资源
- `npm run build:all`: 清理、编译并复制资源

### 技术栈

- TypeScript: 类型安全的 JavaScript 超集
- Chrome Extension API: Chrome 扩展开发接口
- CSS3: 现代化的样式和动画

## 贡献指南

1. Fork 本仓库
2. 创建你的特性分支 (`git checkout -b feature/AmazingFeature`)
3. 提交你的改动 (`git commit -m 'Add some AmazingFeature'`)
4. 推送到分支 (`git push origin feature/AmazingFeature`)
5. 创建一个 Pull Request

## 许可证

本项目采用 MIT 许可证 - 查看 [LICENSE](LICENSE) 文件了解详情